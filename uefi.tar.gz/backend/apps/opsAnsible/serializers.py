from django.contrib.auth import get_user_model
from rest_framework import serializers
from .models import Snippet, LANGUAGE_CHOICES, STYLE_CHOICES

User = get_user_model()
# serializers.Serializer 字段序列化需要手动定义

# class SnippetSerializer(serializers.Serializer):
#     id = serializers.IntegerField(read_only=True)
#     title = serializers.CharField(required=False, allow_blank=True, max_length=100)
#     code = serializers.CharField(style={'base_template': 'textarea.html'})
#     linenos = serializers.BooleanField(required=False)
#     language = serializers.ChoiceField(choices=LANGUAGE_CHOICES, default='python')
#     style = serializers.ChoiceField(choices=STYLE_CHOICES, default='friendly')
#
#     def create(self, validated_data):
#         """
#         Create and return a new `Snippet` instance, given the validated data.
#         """
#         return Snippet.objects.create(**validated_data)
#
#     def update(self, instance, validated_data):
#         """
#         Update and return an existing `Snippet` instance, given the validated data.
#         """
#         instance.title = validated_data.get('title', instance.title)
#         instance.code = validated_data.get('code', instance.code)
#         instance.linenos = validated_data.get('linenos', instance.linenos)
#         instance.language = validated_data.get('language', instance.language)
#         instance.style = validated_data.get('style', instance.style)
#         instance.save()
#         return instance

# serializers.ModelSerializer 数据模型序列化， 自动验证字段，默认内置了create ,update 方法
class SnippetSerializer(serializers.ModelSerializer):
    owner = serializers.ReadOnlyField(source='owner.username')
    class Meta:
        model = Snippet
        fields = '__all__'


class AnsibleSerializer(serializers.Serializer):
    hosts = serializers.CharField(required=True, max_length=200, help_text="主机清单以','隔开")
    module_name = serializers.CharField(required=True, max_length=200, help_text="模块名: shell,command,lineinflie")
    module_args = serializers.CharField(default='', allow_blank=True, allow_null=True, max_length=200, help_text="模块跟的参数")


class NginxIpWhiteSerializer(serializers.Serializer):
    ipaddrs = serializers.CharField(required=True,  max_length=200, help_text="过白的IP','隔开")
    remote_ip = serializers.CharField(required=True, max_length=200, help_text="站点编码")