from django.apps import AppConfig


class AnsibleConfig(AppConfig):
    name = 'apps.opsAnsible'
