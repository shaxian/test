from rest_framework import status, renderers
from django.http import Http404
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.viewsets import ViewSetMixin
import re
from .models import Snippet
from .serializers import SnippetSerializer, AnsibleSerializer, NginxIpWhiteSerializer


# function base view
@api_view(['GET', 'POST'])
def snippet_list(request, format=None):
    """
    List all code snippets, or create a new snippet.
    """
    if request.method == 'GET':
        snippets = Snippet.objects.all()
        serializer = SnippetSerializer(snippets, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = SnippetSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def snippet_detail(request, pk, format=None):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        snippet = Snippet.objects.get(pk=pk)
    except Snippet.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = SnippetSerializer(snippet)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = SnippetSerializer(snippet, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        snippet.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


# class base view

from rest_framework.views import APIView
from django.http import Http404


class SnippetList(APIView):
    """
    List all snippets, or create a new snippet.
    """
    def get(self, request, format=None):
        snippets = Snippet.objects.all()
        serializer = SnippetSerializer(snippets, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = SnippetSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SnippetDetail(APIView):
    """
    Retrieve, update or delete a snippet instance.
    """
    def get_object(self, pk):
        try:
            return Snippet.objects.get(pk=pk)
        except Snippet.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        snippet = self.get_object(pk)
        serializer = SnippetSerializer(snippet)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        snippet = self.get_object(pk)
        serializer = SnippetSerializer(snippet, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        snippet = self.get_object(pk)
        snippet.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# 使用 封装好的 mixins 的 cbv
# 更加友好的brower api
# using the GenericAPIView class to provide the core functionality, and adding in mixins to provide the .retrieve(), .update() and .destroy() actions.


from rest_framework import mixins, generics


class MixinSnippetList(mixins.ListModelMixin, mixins.CreateModelMixin, generics.GenericAPIView):
    queryset = Snippet.objects.all()
    serializer_class = SnippetSerializer

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class MixinSnippetDetail(mixins.RetrieveModelMixin,
                         mixins.UpdateModelMixin,
                         mixins.DestroyModelMixin,
                         generics.GenericAPIView):
    queryset = Snippet.objects.all()
    serializer_class = SnippetSerializer

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

# 使用更高层次的 cbv 代码更加简洁
# generic class-based views
from rest_framework import permissions
from .permissions import IsOwnerOrReadOnly

class GenericSnippetList(generics.ListCreateAPIView):
    queryset = Snippet.objects.all()
    serializer_class = SnippetSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly]


    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class GenericSnippetDetail(ViewSetMixin, generics.RetrieveUpdateDestroyAPIView):
    queryset = Snippet.objects.all()
    serializer_class = SnippetSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly,IsOwnerOrReadOnly]




# 使用 viewset 试图 更加方便

from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

class SnippetViewSet(viewsets.ModelViewSet):
    """
    This viewset automatically provides `list`, `create`, `retrieve`,
    `update` and `destroy` actions.

    Additionally we also provide an extra `highlight` action.
    """
    queryset = Snippet.objects.all()
    serializer_class = SnippetSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly,
                          IsOwnerOrReadOnly]

    @action(detail=True, renderer_classes=[renderers.StaticHTMLRenderer])
    def highlight(self, request, *args, **kwargs):
        snippet = self.get_object()
        return Response(snippet.highlighted)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


from .ansibelapi import AnsiableApi
from rest_framework.exceptions import ParseError

class AnsibleViewSet(viewsets.GenericViewSet):
    serializer_class = AnsibleSerializer

    def create(self, request, *args, **kwargs):
        # 验证字段并抛出异常
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        hosts = request.data.get('hosts')
        hosts_list = re.split(r'[;,\s]\s*', hosts)
        module_name = request.data.get('module_name')
        module_args = request.data.get('module_args')
        # ansible = MyAnsiable2(inventory='{},'.format(ip), connection='smart', remote_user='root', ack_pass='redhat')
        # ansible.run(hosts="all", module=str(module_name), args=str(module_args))
        if module_args:
            ansible = AnsiableApi(connection='smart', remote_user='root')
        else:
            ansible = AnsiableApi(connection='local')
        ansible.inv_obj.add_group('mainweb')
        for host in hosts_list:
            ansible.inv_obj.add_host(group='mainweb', host=host)

        ansible.run(hosts="mainweb", module=str(module_name), args=str(module_args))
        data = ansible.get_result()
        return Response(data, status=status.HTTP_200_OK)


class NginxIpWhiteViewSet(viewsets.GenericViewSet):
    serializer_class = NginxIpWhiteSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        remote_ip = request.data.get('remote_ip')
        ipaddrs = request.data.get('ipaddrs')
        ipaddrs_list = re.split(r'[;,\s]\s*', ipaddrs)
        ansible_var = {
            'line': ipaddrs_list
        }
        ansible = AnsiableApi(connection='smart', remote_user='root')
        ansible.inv_obj.add_group('mainweb')
        ansible.inv_obj.add_host(group='mainweb', host=remote_ip)
        for k in ansible_var:
            ansible.variable_manager.set_host_variable(remote_ip, k, ansible_var[k])
        try:
            ansible.playbook(playbooks=['./apps/opsAnsible/test.yaml'])
            data = ansible.get_result()
        except Exception:
            raise ParseError(detail='ansible 罢工了')
        return Response(data, status=status.HTTP_200_OK)
