from celery import shared_task
from time import sleep



@shared_task()
def sleepy(t):
    sleep(t)
    return None

@shared_task
def add(x,y):
    print('-' * 10 + ' ' + 'Task start' + ' ' + '-' * 10)
    sleepy(20)
    result = x +y
    print('-' * 10 + ' ' + 'Task end' + ' ' + '-' * 10)
    return result
