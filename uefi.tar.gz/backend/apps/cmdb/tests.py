from utils.kangle import CodeGenrate

import math

# url


kangle = CodeGenrate()



#
# def vhosts_list():
#     res = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/list')
#     pages = math.ceil(int(res.json()['count'])/100)
#     vhosts = []
#     for page in range(pages):
#         vhosts += kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/list?page={page}&pagecount=100'.format(page=page)).json()['rows']
#     print(vhosts)
#     return [v['name'] for v in vhosts]



if __name__ == '__main__':
    if kangle.require_login():
        # res = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/list')
        res = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/count/1')
        res2 = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/list?page=0&pagecount=15&ngid=1&pgid=47')
        print(res.json())
        print(res2.json())
