from rest_framework import viewsets, permissions, authentication, status
from rest_framework.mixins import ListModelMixin
from rest_framework.response import Response
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from utils.zabbix import MyZabbix


class ZabbixViewset(ListModelMixin, viewsets.GenericViewSet, MyZabbix):
    """
    list:
        get 查询
    """
    serializer_class = None
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [JSONWebTokenAuthentication, authentication.SessionAuthentication]

    zabbix = MyZabbix()

    def list(self, request, *args, **kwargs):
        try:
            data = self.zabbix.getTrigger
            return Response(data, status=status.HTTP_200_OK)
        except TypeError as e:
            return Response({'jsonrpc': '--', 'result': []}, status=status.HTTP_400_BAD_REQUEST)
