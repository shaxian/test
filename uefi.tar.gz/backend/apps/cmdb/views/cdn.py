from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from utils.kangle import CodeGenrate
# from rest_framework.mixins

import math



class VhostList(APIView):
    def get(self, request):
        kangle = CodeGenrate()
        if kangle.require_login():
            res = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/list')
            data = res.json()
        else:
            data = {'msg': 'cdn接口不通'}
        return Response(data, status=status.HTTP_200_OK)

class GroupsInfo(APIView):
    def get(self, request):
        kangle = CodeGenrate()
        if kangle.require_login():
            res = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/count/1')
            groupinfo = []
            data = res.json()['rows']
            for group in data:
                print(group)
                vhosts_info = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/list?page=0&pagecount=15&ngid=1&pgid={pgid}'.format(pgid=group['pgid']))
                group['vhosts'] = vhosts_info.json()['rows']
                groupinfo.append(group)
            return Response(groupinfo, status=status.HTTP_200_OK)
        else:
            data = {'msg': 'cdn接口不通'}
        return Response(data, status=status.HTTP_400_BAD_REQUEST)

class GroupDetail(APIView):
    def get(self, request, *args, **kwargs):
        pgid = request.query_params.get('pgid')
        # print(pgid)
        kangle = CodeGenrate()
        if kangle.require_login():
            res = kangle.browser.get('http://phpcdn.kk301.vip/api2/user/index.php/vhost/list?page=0&pagecount=15&ngid=1&pgid={pgid}'.format(pgid=pgid))
            data = res.json()
            return Response(data, status=status.HTTP_200_OK)
        else:
            data = {'msg': 'cdn接口不通'}
            return Response(data, status=status.HTTP_400_BAD_REQUEST)

