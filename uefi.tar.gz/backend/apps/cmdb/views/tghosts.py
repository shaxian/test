from django.contrib.auth import get_user_model
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from rest_framework import mixins, viewsets

from cmdb.filter import HostsFilter, AssetCodeFilter
from cmdb.models import Hosts, AssetCode
from cmdb.serializers.tghosts_serializers import GeoIPSerializer, \
    AssetCodeSerializer, HostsListSerializer, HostsCreateSerializer, ChangedBySerializer
from common.pagination import StandardResultsSetPagination

from rest_framework.mixins import ListModelMixin, CreateModelMixin
from rest_framework.response import Response
from rest_framework import status
from rest_framework_extensions.cache.mixins import CacheResponseMixin
from rest_framework import permissions, authentication
from rest_framework_jwt.authentication import JSONWebTokenAuthentication

from django.contrib.gis.geoip2 import GeoIP2

from modellog.mixins import LoggingViewSetMixin

UserProfile = get_user_model()


class HostsListView(LoggingViewSetMixin, mixins.ListModelMixin, mixins.RetrieveModelMixin, mixins.CreateModelMixin,
                    mixins.UpdateModelMixin,
                    mixins.DestroyModelMixin, viewsets.GenericViewSet):
    """
    主机列表
    """
    queryset = Hosts.objects.all()
    serializer_class = HostsListSerializer
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [JSONWebTokenAuthentication, authentication.SessionAuthentication]
    pagination_class = StandardResultsSetPagination

    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filter_class = HostsFilter
    search_fields = ('host_type', '=master_ip', 'host_code__name', 'host_code__in_cname', 'host_code__out_cname',
                     'host_code__source_cname')
    ordering = ('-add_time',)

    def get_serializer_class(self):
        # 根据请求类型动态变更serializer
        if self.action == 'create':
            return HostsCreateSerializer
        elif self.action == 'list' or self.action == 'retrieve':
            return HostsListSerializer
        return HostsCreateSerializer


class AssetCodeViewSet(viewsets.ModelViewSet):
    """
    站点编码筛选cname
    """
    queryset = AssetCode.objects.all()
    serializer_class = AssetCodeSerializer
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [JSONWebTokenAuthentication, authentication.SessionAuthentication]
    pagination_class = StandardResultsSetPagination

    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filter_class = AssetCodeFilter
    search_fields = ('=name', 'in_cname', 'out_cname', 'source_cname',)
    ordering = ('-id',)


class ChangedByUserViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """
    用户ID,username
    """
    queryset = UserProfile.objects.all()
    serializer_class = ChangedBySerializer
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [JSONWebTokenAuthentication, authentication.SessionAuthentication]
    # pagination_class = StandardResultsSetPagination

    filter_backends = (filters.SearchFilter, filters.OrderingFilter)
    search_fields = ('id', '=username',)
    ordering = ('id',)


class GeoIPViewset(CacheResponseMixin, ListModelMixin, CreateModelMixin, viewsets.GenericViewSet):
    """
    list:
        get 查询
    create:
        post 查询
    """
    serializer_class = GeoIPSerializer
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [JSONWebTokenAuthentication, authentication.SessionAuthentication]

    geo = GeoIP2()

    def list(self, request, *args, **kwargs):
        try:
            ipaddr = self.request.query_params.get('ipaddr')
            ip_city = self.geo.city(ipaddr)
            ip_country = self.geo.country(ipaddr)
        except TypeError as e:
            return Response({'msg': '参数缺失:ipaddr'}, status=status.HTTP_400_BAD_REQUEST)

        return Response({'ip': ipaddr, 'city': ip_city, 'country': ip_country}, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ipaddr = serializer.validated_data["ipaddr"]
        ip_city = self.geo.city(ipaddr)
        ip_country = self.geo.country(ipaddr)

        return Response({'ip': ipaddr, 'city': ip_city, 'country': ip_country}, status=status.HTTP_200_OK)
