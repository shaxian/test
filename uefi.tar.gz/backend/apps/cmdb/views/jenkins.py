from rest_framework import viewsets, permissions, authentication, status
from rest_framework.mixins import ListModelMixin
from rest_framework.response import Response
from rest_framework_jwt.authentication import JSONWebTokenAuthentication

from utils.jenkins import MyJenkins



class JenkinsViewset(ListModelMixin, viewsets.GenericViewSet):
    """
    list:
        get 查询
    """
    serializer_class = None
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [JSONWebTokenAuthentication, authentication.SessionAuthentication]

    jenkins = MyJenkins()

    def list(self, request, *args, **kwargs):
        try:
            data = self.jenkins.getBuildHistory
            return Response(data, status=status.HTTP_200_OK)
        except TypeError as e:
            return Response({'msg': '超时'}, status=status.HTTP_400_BAD_REQUEST)
