from django.contrib.auth import get_user_model
from django.db import models
from simple_history.models import HistoricalRecords

User = get_user_model()


class AssetCode(models.Model):
    name = models.CharField(unique=True, max_length=10, verbose_name="asset_code", help_text="asset_code")
    out_cname = models.CharField(default="", null=True, blank=True, max_length=50, verbose_name="外部cname",
                                 help_text="外部cname")
    in_cname = models.CharField(default="", null=True, blank=True, max_length=50, verbose_name="内部cname",
                                help_text="内部cname")
    source_cname = models.CharField(default="", null=True, blank=True, max_length=50, verbose_name="回源cname",
                                    help_text="回源cname")
    idc = models.CharField(default="", null=True, blank=True, max_length=10, verbose_name="机房地址", help_text="机房地址")
    desc = models.TextField(max_length=350, null=True, blank=True, default='', verbose_name='描述')

    class Meta:
        verbose_name = "资产编码"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


class Hosts(models.Model):
    HOST_TYPE = (
        ('zzzk', "主站主库"),
        ('bfck', "备份从库"),
        ('zz', "主站"),
        ('bf', "备份"),
        ('zk', "主库"),
        ('ck', "从库")
    )
    IDC_CHOICE = (
        ('hk', '香港'),
        ('kr', '韩国')
    )
    SERVICE_CHOICE = (
        ('prod', '生产主机'),
        ('mobile', '手机主机'),
        ('center', '中心主机'),
        ('chess', '棋牌主机'),
        ('monitor', '监控主机'),
        ('collect', '采集主机'),
        ('cdn', 'CDN节点')

    )
    host_type = models.CharField(max_length=10, choices=HOST_TYPE, verbose_name="主机角色", help_text="主机角色")
    host_code = models.ForeignKey(AssetCode, null=True, blank=True, on_delete=models.SET_NULL, verbose_name="站点编码",
                                  help_text="站点编码")
    service_type = models.CharField(default='prod', max_length=10, choices=SERVICE_CHOICE, verbose_name="服务类型",
                                    help_text="服务类型")
    master_ip = models.GenericIPAddressField(verbose_name="主IP地址", help_text="主IP地址", default="")
    fu_ip = models.CharField(default="", null=True, blank=True, max_length=50, verbose_name="副IP地址",
                             help_text="副IP地址")
    app_ip = models.CharField(default="", null=True, blank=True, max_length=50, verbose_name="AppIP地址",
                              help_text="AppIP地址")
    cdn_ip = models.CharField(default="", null=True, blank=True, max_length=50, verbose_name="CdnIP地址",
                              help_text="CdnIP地址")
    add_time = models.DateTimeField(auto_now_add=True, verbose_name="添加时间")
    modify_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")
    idc = models.CharField(max_length=10, choices=IDC_CHOICE, verbose_name="机房地址", help_text="机房地址")
    is_active = models.BooleanField(default=False, verbose_name="是否上线", help_text="是否上线")
    changed_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, )
    history = HistoricalRecords(excluded_fields=['add_time', 'modify_time'])

    class Meta:
        verbose_name = "主机列表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.host_code.name

    @property
    def _history_user(self):
        return self.changed_by

    @_history_user.setter
    def _history_user(self, value):
        self.changed_by = value
