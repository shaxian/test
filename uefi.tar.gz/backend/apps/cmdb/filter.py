from django_filters import rest_framework as filters
from .models import Hosts, AssetCode


class HostsFilter(filters.FilterSet):
    """
    过滤器
    """
    class Meta:
        model = Hosts
        fields = ['is_active', 'idc', 'service_type', 'host_type']


class AssetCodeFilter(filters.FilterSet):
    """
    过滤器
    """
    name = filters.CharFilter(field_name="name", lookup_expr='icontains')

    class Meta:
        model = AssetCode
        fields = ['name', 'in_cname']
