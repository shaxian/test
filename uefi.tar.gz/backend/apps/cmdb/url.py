from django.urls import include
from django.conf.urls import url
from rest_framework import routers

from cmdb.views import cdn
from cmdb.views.jenkins import JenkinsViewset
from cmdb.views.zabbix_monitor import ZabbixViewset

router = routers.DefaultRouter()
router.register(r'zabbix', ZabbixViewset, base_name='zabbix')
router.register(r'jks-builds', JenkinsViewset, base_name='jks-builds')


app_name = 'cdn'

urlpatterns = [
    url('', include(router.urls)),
    url(r'vhostlist/', cdn.VhostList.as_view(), name='vhostlist'),
    url(r'groupsinfo/', cdn.GroupsInfo.as_view(), name='groupinfo'),
    url(r'groupdetail/', cdn.GroupDetail.as_view(), name='onlinevhost'),

]
