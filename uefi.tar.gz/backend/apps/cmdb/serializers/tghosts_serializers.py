from django.contrib.auth import get_user_model
from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator, UniqueValidator

from cmdb.models import Hosts, AssetCode

UserProfile = get_user_model()


class AssetCodeSerializer(serializers.ModelSerializer):
    """
    资产编码
    """
    name = serializers.CharField(
        validators=[UniqueValidator(queryset=AssetCode.objects.all(), message='该站点编码已经存在')]
    )

    class Meta:
        model = AssetCode
        fields = '__all__'


class ChangedBySerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['id', 'username', ]


class HostsListSerializer(serializers.ModelSerializer):
    """
    主机列表
    """
    changed_by = ChangedBySerializer()

    class Meta:
        model = Hosts
        fields = "__all__"
        depth = 1


class HostsCreateSerializer(serializers.ModelSerializer):
    """
    主机列表
    """

    class Meta:
        model = Hosts
        validators = [
            UniqueTogetherValidator(
                queryset=Hosts.objects.all(),
                fields=['host_type', 'master_ip'],
                message="已经添加过了"
            )
        ]
        fields = "__all__"


class GeoIPSerializer(serializers.Serializer):
    ipaddr = serializers.IPAddressField(required=True, help_text="IP地址")

    def validate(self, attrs):
        """自定义validate 是所有字段的集中验证"""
        return attrs

    """
    以上方法都是在serializer.is_valid(raise_exception=True)的时候通过钩子去执行，所以不需要手动执行这两个方法。
    """

    """通过钩子自定义字段验证，validate_[字段名称]"""
    # def validate_mobile(self, mobile):
    #     """
    #     验证手机号码
    #     """
    #
    #     # 手机是否注册
    #     if User.objects.filter(mobile=mobile).count():
    #         raise serializers.ValidationError(detail="用户已经存在")
    #
    #     # 验证手机号码是否合法
    #     if not re.match(REGEX_MOBILE, mobile):
    #         raise serializers.ValidationError(detail="手机号码非法")
    #
    #     # 验证码发送频率
    #     one_mintes_ago = datetime.now() - timedelta(hours=0, minutes=1, seconds=0)
    #     if VerifyCode.objects.filter(add_time__gt=one_mintes_ago, mobile=mobile).count():
    #         raise serializers.ValidationError("距离上一次发送未超过60s")
    #
    #     return mobile
