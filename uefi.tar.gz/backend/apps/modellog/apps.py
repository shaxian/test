from django.apps import AppConfig


class ModellogConfig(AppConfig):
    name = 'modellog'
