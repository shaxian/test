from rest_framework import serializers

from rest_framework.pagination import PageNumberPagination


class CommonPagination(PageNumberPagination):
    '''
    分页设置
    '''
    page_size = 10
    page_size_query_param = 'size'


class TreeSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    label = serializers.CharField(max_length=20)
    pid = serializers.PrimaryKeyRelatedField(read_only=True)
