from rest_framework import viewsets
from rest_framework.pagination import PageNumberPagination
from modellog.mixins import LoggingViewSetMixin
from rest_framework.response import Response
from rest_framework.decorators import action


class DefaultPagination(PageNumberPagination):
    page_size = 100
    page_size_query_param = 'pagesize'
    page_query_param = 'page'
    max_page_size = 1000

class BaseGenericViewSet(LoggingViewSetMixin, viewsets.GenericViewSet):
    pagination_class = DefaultPagination