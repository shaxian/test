# coding:utf-8
import requests
import json


class MyZabbix:
    def __init__(self):
        self.url = "http://monitor-kr.yibofafa666.com/api_jsonrpc.php"
        self.data = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "user": "yunwei",
                "password": "yunwei123"
            },
            "id": 1
        }
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0",
            "Content-type": "application/json-rpc"
        }
        self.token = self.getRequest()["result"]

    def getRequest(self):
        self.sendData = json.dumps(self.data)
        req = requests.post(url=self.url, headers=self.headers, data=self.sendData)
        content = req.json()
        return content

    @property
    def getTrigger(self):
        """
        获取报警
        """

        if self.token:
            self.data = {"jsonrpc": "2.0", "method": "trigger.get", "params": {
                "output": [
                    "triggerid",
                    "description",
                    "lastchange",
                    "priority"
                ],
                "filter": {
                    "value": 1
                },
                "sortfield": "priority",
                "sortorder": "DESC",
                # 只返回严重级别大于或等于给定严重性的触发器
                "min_severity": 3,
                # 在依赖于其他触发器的问题状态中跳过触发器。 请注意：如果禁用，禁用监控项或禁用主机监控项，其他触发器将被忽略
                "skipDependent": 1,
                # 只返回所属被监控主机启用触发器，且包含已启用的监控项.
                "monitored": 1,
                # 只返回所属被监控主机的已启用触发器.
                "active": 1,
                "expandDescription": 1,
                "selectHosts": ['host'],
                "selectGroups": ['name'],
                "only_true": 1
            }, "auth": self.token, "id": 3}

            result = self.getRequest()
            # print(self.data)
            return result
        else:
            raise KeyError("we have no token")


if __name__ == "__main__":
    m = MyZabbix()
    media = m.getTrigger
    # print(json.dumps(media))
    print(media)
    # hosts = m.getHost()["result"]
    # for host in hosts:
    #     print(host)
    # print(len(hosts))

"""
method 此选项意为调用zabbix api的具体操作，如获取监控的主机，主机组，触发器等，此处trigger.get为获取zabbix 触发器状态（根据下面设定条件获取当前告警的触发器）
params 需要传递给API method的参数，这里是trigger.get下的一些属性（诸多属性请移步官网https://www.zabbix.com/documentation/3.4/zh/manual/api/reference/trigger/get）
triggerid
触发器id
description
触发器内容秒数
priority
触发器等级1-5，5最大 1最小
filter
过滤信息 value 1 表示启动的
sortfield
排序
sortorder
正排还是倒排
min_severity
大于等于给定的触发器级别，这里是大于等于严重
skipDependent
跳过依赖于其他触发器的问题状态中的触发器。请注意，如果禁用了其他触发器，则会禁用其他触发器，禁用项目或禁用项目主机。
monitored
属于受监控主机的已启用触发器，并仅包含已启用的项目
active
只返回属于受监控主机的启用的触发器（与上条意思差不多，至于什么区别，未测）
expandDescription
在触发器的名称中展开宏
selectHosts
在结果中返回关联的主机信息（意思就是显示出那台主机告警的）
selectGroups
在结果中返回关联的主机组信息（意思就是显示出那个主机组告警的）
only_true
只返回最近处于问题状态的触发器（个人理解为处于告警状态的主机）
"""
