# coding:utf-8
import requests
import json


class MyJenkins:
    def __init__(self):
        self.base_url = "http://jenkins.zhushuqt.com/"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0",
            "Content-type": "application/json",
            "Authorization": "Basic YW5kcm9pZDoxMjVlZmY2MmRlOGZkZmNhNmJkMmUzNzRkMzA0YzY2Mg=="
        }
    @property
    def getBuildHistory(self):
        api = self.base_url + 'api/json?pretty=true&tree=jobs[lastBuild[fullDisplayName[*],result[*],url[*],timestamp[*]]]'
        res = requests.get(url=api, headers=self.headers)
        content = res.json()
        return content


if __name__ == "__main__":
    m = MyJenkins()
    res = m.getBuildHistory
    print(res)
