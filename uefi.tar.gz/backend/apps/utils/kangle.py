#!/usr/bin/env python3
import base64
import json
import re

import requests
import pytesseract
from PIL import Image
from collections import defaultdict
from io import BytesIO


class CodeGenrate(object):
    def __init__(self):
        self.code_url = 'http://phpcdn.kk301.vip/user/?c=session&a=create_code'
        self.customize_header = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'
        }
        self.browser = requests.session()
        self.site_url = 'http://phpcdn.kk301.vip/user/?c=vhost&a=vhostLogin&name='  # + vhost
        self.login_url = "http://phpcdn.kk301.vip/user/"
        self.login_params = dict(c='session', a='login')

        self.login_data = dict(username=base64.b64decode(b'OTIwMDk2NDEzQHFxLmNvbQ==').decode('utf-8'),
                          passwd=base64.b64decode(b'eW91eGloYWhhQWRtaW4yMDE5').decode('utf-8'), code='')


    def get_threshold(self, image):
        pixel_dict = defaultdict(int)
        # 像素及该像素出现次数的字典
        rows, cols = image.size
        for i in range(rows):
            for j in range(cols):
                pixel = image.getpixel((i, j))
                pixel_dict[pixel] += 1
        count_max = max(pixel_dict.values())
        # 获取像素出现出多的次数
        pixel_dict_reverse = {v: k for k, v in pixel_dict.items()}
        # 获取出现次数最多的像素点
        threshold = pixel_dict_reverse[count_max]
        return threshold

    def get_bin_table(self, threshold):
        # 获取灰度转二值的映射table
        table = []
        for i in range(256):
            # 在threshold的适当范围内进行处理
            rate = 0.01
            if threshold * (1 - rate) <= i <= threshold * (1 + rate):
                table.append(1)
            else:
                table.append(0)
        return table

    # 去掉二值化处理后的图片中的噪声点
    def cut_noise(self, image):
        rows, cols = image.size  # 图片的宽度和高度
        change_pos = []  # 记录噪声点位置
        # 遍历图片中的每个点，除掉边缘
        for i in range(1, rows - 1):
            for j in range(1, cols - 1):
                # pixel_set用来记录该店附近的黑色像素的数量
                pixel_set = []
                # 取该点的邻域为以该点为中心的九宫格
                for m in range(i - 1, i + 2):
                    for n in range(j - 1, j + 2):
                        if image.getpixel((m, n)) != 1:  # 1为白色,0位黑色
                            pixel_set.append(image.getpixel((m, n)))
                # 如果该位置的九宫内的黑色数量小于等于4，则判断为噪声
                if len(pixel_set) <= 4:
                    change_pos.append((i, j))
        # 对相应位置进行像素修改，将噪声处的像素置为1（白色）
        for pos in change_pos:
            image.putpixel(pos, 1)
        return image

    def OCR_lmj(self, image):
        # image = Image.open(img_path) # 打开图片文件
        imgry = image.convert('L')  # 转化为灰度图
        # 获取图片中的出现次数最多的像素，即为该图片的背景
        max_pixel = self.get_threshold(imgry)
        # 将图片进行二值化处理
        table = self.get_bin_table(threshold=max_pixel)
        out = imgry.point(table, '1')
        # 去掉图片中的噪声（孤立点）
        out = self.cut_noise(out)
        # 识别图片中的数字和字母
        # out.show()
        text = pytesseract.image_to_string(out)
        # 去掉识别结果中的特殊字符
        exclude_char_string = ' .:\\|\'\"?![],()~@#$%^&*_+-={};<>/¥'
        text = ''.join([x for x in text if x not in exclude_char_string])
        return text

    def get_code(self):
        while True:
            self.browser.headers.update(self.customize_header)
            respose = self.browser.get(url=self.code_url)
            image = Image.open(BytesIO(respose.content))
            code = self.OCR_lmj(image)
            if len(code) == 4:
                break
        print(code)
        return code

    def require_login(self):
        try:
            with open('/tmp/cookie', 'r') as f:
                cookie = json.loads(f.read())

            self.browser.cookies.clear()
            self.browser.cookies.update(cookie)
        except Exception as e:
            with open('/tmp/cookie', 'w') as f:
                cook = {}
                f.write(json.dumps(cook))
        try:
            res = self.browser.get('http://phpcdn.kk301.vip/user/?c=index&a=getCount').json()
            # print(res)
        except Exception as e:
            print(e)
            for i in range(10):
                self.login_data.update(code=self.get_code())
                response = self.browser.post(url=self.login_url, params=self.login_params, data=self.login_data)
                error_login = re.search(r'<a href="/site/" >站点登录\?验证码错误</a>', response.text)
                if error_login:
                    print('登入失败')
                    continue
                else:
                    print('login success !!')
                    with open('/tmp/cookie', 'w') as f:
                        cook = self.browser.cookies.get_dict()
                        f.write(json.dumps(cook))
                    return True
            return False
        return True
