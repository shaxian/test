from django.urls import include
from django.conf.urls import url

from users.views.passmanager import PassManagerViewSet
from .views import user, menu, organization, role
from rest_framework import routers

router = routers.DefaultRouter()
router.register(r'menus', menu.MenuViewSet, base_name="menus")
router.register(r'users', user.UserViewSet, base_name="users")
router.register(r'organizations', organization.OrganizationViewSet, base_name="organization")
router.register(r'roles', role.RoleViewSet, base_name="roles")
router.register(r'userinfo', user.UserInfoViewSet, base_name="userinfo")
router.register(r'menu-tree', menu.MenuTreeViewSet, base_name='menu-tree')
router.register(r'organization-tree', organization.OrganizationTreeViewSet, base_name='organization-tree')
router.register(r'pass', PassManagerViewSet, base_name='pass')

app_name = 'users'

urlpatterns = [
    url('', include(router.urls)),
    url(r'organization/user/tree/', organization.OrganizationUserTreeView.as_view(), name='organization_user_tree'),
    url(r'user/list/', user.UserListView.as_view(), name='user_list'),
    # url(r'user/info/', user.UserInfoView.as_view(), name='user_info'),
    url(r'build/menus/', user.UserBuildMenuView.as_view(), name='build_menus'),
]
