from rest_framework import serializers

from users.models import PassManager


class PassManagerSerializer(serializers.ModelSerializer):
    """
    密码管理序列化
    """

    class Meta:
        model = PassManager
        fields = "__all__"
