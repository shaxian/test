from rest_framework import serializers
from users.models import Menu


class MenuSerializer(serializers.ModelSerializer):
    """
    菜单序列化
    """

    class Meta:
        model = Menu
        fields = ('id', 'label', 'icon', 'path', 'is_show', 'is_frame', 'sort', 'component', 'pid', 'redirect')
        extra_kwargs = {'label': {'required': True, 'error_messages': {'required': '必须填写菜单名'}}}


class ChildrenSerializer(serializers.ModelSerializer):
    """
    子菜单序列化
    """

    class Meta:
        model = Menu
        fields = ('id', 'label', 'pid')


class ChildrenDetailSerializer(serializers.ModelSerializer):
    """
    子菜单序列化
    """

    class Meta:
        model = Menu
        fields = ('id', 'label', 'icon', 'path', 'is_show', 'is_frame', 'sort', 'component', 'pid')


class MenuTreeSerializer(serializers.ModelSerializer):
    """
    简单菜单树序列化
    """
    children = ChildrenSerializer(many=True)

    class Meta:
        model = Menu
        # depth = 1
        fields = ('id', 'label', 'children', 'pid')


class MenuDetailTreeSerializer(serializers.ModelSerializer):
    """
    详细菜单树序列化
    """
    children = ChildrenDetailSerializer(many=True)

    class Meta:
        model = Menu
        # depth = 1
        fields = ('id', 'label', 'icon', 'path', 'is_show', 'is_frame', 'sort', 'component', 'children', 'pid', 'redirect')
