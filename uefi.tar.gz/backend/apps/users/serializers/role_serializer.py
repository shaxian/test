from django.contrib.auth import get_user_model
from rest_framework import serializers
from ..models import Role

UserProfile = get_user_model()

class SubUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ('id', 'name')

class RoleListSerializer(serializers.ModelSerializer):
    '''
    角色序列化
    '''
    user = SubUserSerializer(many=True)
    class Meta:
        model = Role
        fields = '__all__'
        extra_fields = [
            'user'
        ]


class RoleModifySerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(many=True, queryset=UserProfile.objects.all())
    class Meta:
        model = Role
        fields = '__all__'
        extra_fields = [
                    'user'
                ]