from rest_framework import authentication
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet, ReadOnlyModelViewSet
from users.models import Menu
from users.serializers.menu_serializer import MenuSerializer, MenuTreeSerializer, MenuDetailTreeSerializer
from common.custom import CommonPagination
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.permissions import IsAuthenticated
from rest_framework_jwt.authentication import JSONWebTokenAuthentication


class MenuTreeViewSet(ReadOnlyModelViewSet):
    """
    菜单树
    """
    queryset = Menu.objects.filter(pid=None)
    serializer_class = MenuTreeSerializer
    # pagination_class = CommonPagination
    pagination_class = None
    filter_backends = (SearchFilter, OrderingFilter)
    search_fields = ('label',)
    ordering_fields = ('sort',)
    authentication_classes = (JSONWebTokenAuthentication, authentication.SessionAuthentication)
    permission_classes = (IsAuthenticated,)


class MenuViewSet(ModelViewSet):
    """
    菜单管理：增删改查
    """
    queryset = Menu.objects.all()
    serializer_class = MenuSerializer
    pagination_class = CommonPagination
    filter_backends = (SearchFilter, OrderingFilter)
    search_fields = ('label',)
    ordering_fields = ('sort',)
    authentication_classes = (JSONWebTokenAuthentication, authentication.SessionAuthentication)
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        # 根据请求类型动态变更serializer
        if self.action == 'list':
            return MenuDetailTreeSerializer
        return MenuSerializer

    def list(self, request, *args, **kwargs):
        queryset = Menu.objects.filter(pid=None)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
