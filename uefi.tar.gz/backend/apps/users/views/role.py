from rest_framework import authentication
from rest_framework.viewsets import ModelViewSet
from ..models import Role
from ..serializers.role_serializer import RoleListSerializer, RoleModifySerializer
from common.custom import CommonPagination
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated


class RoleViewSet(ModelViewSet):
    '''
    角色管理：增删改查
    '''

    queryset = Role.objects.all()
    serializer_class = RoleListSerializer
    pagination_class = CommonPagination
    filter_backends = (SearchFilter, OrderingFilter)
    search_fields = ('name',)
    ordering_fields = ('id',)
    authentication_classes = (JSONWebTokenAuthentication, authentication.SessionAuthentication)
    permission_classes = (IsAuthenticated,)

    def get_serializer_class(self):
        if self.action == 'list':
            return RoleListSerializer
        return RoleModifySerializer
