from rest_framework import authentication
from rest_framework.viewsets import ModelViewSet
from users.models import PassManager
from users.serializers.pass_serializer import PassManagerSerializer
from common.custom import CommonPagination
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated


class PassManagerViewSet(ModelViewSet):
    """
    增删改查
    """
    queryset = PassManager.objects.all()
    serializer_class = PassManagerSerializer
    pagination_class = CommonPagination
    filter_backends = (SearchFilter, OrderingFilter)
    search_fields = ('platform', 'username')
    ordering_fields = ('-id',)
    authentication_classes = (JSONWebTokenAuthentication, authentication.SessionAuthentication)
    permission_classes = (IsAuthenticated,)
