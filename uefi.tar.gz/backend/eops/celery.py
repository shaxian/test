from __future__ import absolute_import, unicode_literals
import os
from celery import Celery, platforms
from django.conf import settings

from eops import celeryconfig

# 设置django环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'eops.settings')

app = Celery('eops')
# platforms.C_FORCE_ROOT = True  # use root

app.config_from_object(celeryconfig, namespace='CELERY')

# 自动发现task，这个配置会自动从每个app目录下去发现tasks.py文件
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)


@app.task(bind=True)
def debug_task(self):
    print('Request: {0!r}'.format(self.request))
