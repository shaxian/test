# Celery settings
CELERY_BROKER_URL = 'redis://172.16.1.6:6379/0'  # Broker配置，使用Redis作为消息中间件

CELERY_RESULT_BACKEND = 'redis://172.16.1.6:6379/0'  # Backend设置，使用redis作为后端结果存储

CELERY_TIMEZONE = 'Asia/Shanghai'

CELERY_ENABLE_UTC = False

CELERYD_FORCE_EXECV = True  # 防止任务死锁

CELERYD_CONCURRENCY = 8  # 并发的worker数量

CELERY_ACKS_LATE = True

CELERYD_MAX_TASKS_PER_CHILD = 100  # 每个worker最多执行的任务数

CELERYD_TASK_TIME_LIMIT = 15 * 60  # 任务超时时间

CELERY_TRACK_STARTED = True,
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_ACCEPT_CONTENT = ['json']