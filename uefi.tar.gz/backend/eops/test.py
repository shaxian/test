#!/usr/bin/python
# -*- coding: utf-8 -*-

import subprocess

site_name = input('输入站点编码：')
m = subprocess.check_output(f'echo "{site_name}" |md5sum', shell=True).decode('utf-8')
token = m[8:24]
ip_source = input('输入IP以逗号隔开：')
iprange = ip_source.split()
for ip in iprange:
    print(
        f""" GRANT ALTER,SELECT,INSERT,UPDATE,DELETE,CREATE,DROP,INDEX,CREATE TEMPORARY TABLES,LOCK TABLES ON gameplat_analysis.* TO gameplat_analysis_dev@'{ip}' IDENTIFIED BY 'xjVXkB>Q6JpB61r{token}'; """)
    print(
        f""" GRANT ALTER,SELECT,INSERT,UPDATE,DELETE,CREATE,DROP,INDEX,CREATE TEMPORARY TABLES,LOCK TABLES ON gameplat_sc_data.* TO gameplat_sc_data_dev@'{ip}' IDENTIFIED BY 'OeJr)4uRGAuf(BH{token}'; """)
    print(
        f""" GRANT ALTER,SELECT,INSERT,UPDATE,DELETE,CREATE,DROP,INDEX,CREATE TEMPORARY TABLES,LOCK TABLES ON gameplat_cms.* TO gameplat_cms_dev@'{ip}' IDENTIFIED BY '9ckhq<64RZ2YUSR{token}'; """)
    print(
        f""" GRANT REPLICATION SLAVE ON *.* TO myrync@'{ip}' IDENTIFIED BY  'MyryncCloud'; """)

print(""" #################### """)
print(""" CHANGE MASTER TO
  MASTER_HOST='154.223.2.144',
  MASTER_USER='myrync',
  MASTER_PASSWORD='MyryncCloud',
  MASTER_PORT=16303,
  MASTER_LOG_FILE='mysql-bin.001085',
  MASTER_LOG_POS=963507606,
  MASTER_CONNECT_RETRY=15; """)